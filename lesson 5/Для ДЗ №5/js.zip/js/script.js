let menuItem = document.getElementsByClassName("menu-item")[0],
    menu = document.getElementsByClassName("menu"),
    column = document.getElementsByClassName("column"),
    adv = document.getElementsByClassName("adv");
    
    menu.insertBefore(menuItem[2], menuItem[1]);